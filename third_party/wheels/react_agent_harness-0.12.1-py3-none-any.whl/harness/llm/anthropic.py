"""
Anthropic LLM adapter (direct API key, no OAuth).

Implements the harness LLM client contract:
  - async def complete(system, messages, **kwargs) -> dict
  - async def stream_complete(system, messages) -> AsyncGenerator[str, None]

Prompt caching
--------------
Enabled by default (`prompt_caching=True`). When active:
  - The system prompt is sent as a content-block list with `cache_control`
    on the last block so Anthropic can cache the compiled KV state.
  - The last user message's text block also gets `cache_control` so
    multi-turn ReAct loops that share a common leading prefix cache cheaply.

Cache reads cost ~10% of normal input tokens. Callers that pass a `cost_fn`
receive `cache_read_tokens` and `cache_creation_tokens` in the usage dict so
they can apply the correct per-tier pricing.

Usage tracking
--------------
`last_usage` is populated after every call::

    {
        "tokens_in": int,                 # non-cached input tokens
        "tokens_out": int,                # output tokens
        "cache_read_tokens": int,         # tokens served from cache
        "cache_creation_tokens": int,     # tokens written to cache
        "model": str,                     # model id echoed from response
    }

Cost tracking
-------------
An optional `cost_fn(usage) -> float` may be supplied to convert the usage
dict to dollars. This is handy for callers that know the per-model pricing
schedule. When `set_budget(guard)` is called (typically by AgentRuntime),
the adapter forwards computed costs to the guard's `add_cost()` method.

Install:
    pip install -e ".[anthropic]"

Usage:
    from harness.llm.anthropic import AnthropicLLM
    llm = AnthropicLLM(model="claude-sonnet-4-6")  # reads ANTHROPIC_API_KEY
"""

from __future__ import annotations

import logging
import os
from collections.abc import AsyncGenerator, Callable
from typing import Any

from harness.llm.reasoning import (
    ANTHROPIC_REASONING_EFFORTS,
    ReasoningEffort,
    validate_reasoning_effort,
)

logger = logging.getLogger(__name__)


# Anthropic's ``/v1/models`` endpoint, like OpenAI's, doesn't expose
# per-model context limits. Maintain a small lookup; users running new
# models pass ``context_window=N`` explicitly.
#
# Anthropic frames "context window" as input-only — output has its own
# ``max_tokens`` ceiling, billed separately. So ``input_token_budget``
# below is just the window minus a safety slack.
_ANTHROPIC_CONTEXT_WINDOWS: dict[str, int] = {
    "claude-sonnet-4-6": 200_000,
    "claude-sonnet-4": 200_000,
    "claude-opus-4": 200_000,
    "claude-haiku-4": 200_000,
    "claude-3-7-sonnet": 200_000,
    "claude-3-5-sonnet": 200_000,
    "claude-3-5-haiku": 200_000,
    "claude-3-opus": 200_000,
}
_ANTHROPIC_CONTEXT_WINDOW_FALLBACK = 8_000
_ANTHROPIC_TOKEN_BUDGET_SAFETY = 512


def _lookup_anthropic_context_window(model: str) -> int:
    if model in _ANTHROPIC_CONTEXT_WINDOWS:
        return _ANTHROPIC_CONTEXT_WINDOWS[model]
    for prefix in sorted(_ANTHROPIC_CONTEXT_WINDOWS, key=len, reverse=True):
        if model.startswith(prefix):
            return _ANTHROPIC_CONTEXT_WINDOWS[prefix]
    logger.warning(
        "AnthropicLLM: unknown model %r — defaulting context_window to %d. "
        "Pass `context_window=N` to AnthropicLLM(...) for the real value.",
        model,
        _ANTHROPIC_CONTEXT_WINDOW_FALLBACK,
    )
    return _ANTHROPIC_CONTEXT_WINDOW_FALLBACK


_JSON_REMINDER = "Respond with a JSON object only."


def _append_json_reminder(messages: list[dict]) -> list[dict]:
    """Append a JSON reminder to the last user message's text content.

    Anthropic has no response_format='json_object' equivalent. Appending a
    brief instruction to the last user message re-anchors the model to JSON
    output after markdown-rich observations, without assistant prefill (which
    Bedrock rejects).
    """
    for i in range(len(messages) - 1, -1, -1):
        msg = messages[i]
        if msg.get("role") != "user":
            continue
        content = msg.get("content")
        if isinstance(content, list) and content and content[-1].get("type") == "text":
            updated = [
                *content[:-1],
                {**content[-1], "text": content[-1]["text"] + f"\n{_JSON_REMINDER}"},
            ]
            return [*messages[:i], {**msg, "content": updated}, *messages[i + 1 :]]
        break
    return messages


class AnthropicLLM:
    def __init__(
        self,
        *,
        model: str = "claude-sonnet-4-6",
        api_key: str | None = None,  # falls back to ANTHROPIC_API_KEY env
        # Generous default — matches OpenAILLM's max_completion_tokens=4096.
        # ReAct ``thought`` fields + finish answers were getting clipped at
        # 1024 once observations grew large; 4096 leaves comfortable headroom
        # while staying below Claude 3.5 / 3.7's per-call output ceilings.
        max_tokens: int = 4096,
        cost_fn: Callable[[dict], float] | None = None,
        prompt_caching: bool = True,
        # Explicit context window override; see ``_lookup_anthropic_context_window``.
        context_window: int | None = None,
        reasoning_effort: ReasoningEffort | None = None,
    ) -> None:
        try:
            import anthropic
        except ImportError as e:
            raise ImportError(
                'anthropic package not installed. Run: pip install -e ".[anthropic]"'
            ) from e

        resolved_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        self._client = anthropic.AsyncAnthropic(api_key=resolved_key)
        self._model = model
        self._max_tokens = max_tokens
        self._cost_fn = cost_fn
        self._prompt_caching = prompt_caching
        self._context_window = context_window or _lookup_anthropic_context_window(model)
        self._reasoning_effort = validate_reasoning_effort(
            reasoning_effort,
            provider="anthropic",
            allowed=ANTHROPIC_REASONING_EFFORTS,
        )
        self._budget: Any = None
        # Populated after every successful call; streaming callers read it here.
        self.last_usage: dict | None = None

    @property
    def context_window(self) -> int:
        """Input-token context window for the configured model."""
        return self._context_window

    @property
    def input_token_budget(self) -> int:
        """Tokens available for the prompt. Anthropic frames context as
        input-only; ``max_tokens`` for output is enforced separately, so
        no output-reserve subtraction is needed here."""
        return max(1024, self._context_window - _ANTHROPIC_TOKEN_BUDGET_SAFETY)

    def set_budget(self, guard: Any) -> None:
        """Inject a BudgetGuard; AgentRuntime calls this at the start of each run."""
        self._budget = guard

    # ── Non-streaming ──────────────────────────────────────────────────────────

    async def complete(
        self,
        system: str | None,
        messages: list[dict],
        *,
        source: str | None = None,
        **kwargs: Any,
    ) -> dict:
        max_tokens = int(kwargs.pop("max_tokens", self._max_tokens))
        json_mode = kwargs.get("response_format", {}).get("type") == "json_object"
        sys_blocks = _system_blocks(system, prompt_caching=self._prompt_caching)
        built_messages = _build_messages(messages, prompt_caching=self._prompt_caching)
        if json_mode:
            built_messages = _append_json_reminder(built_messages)

        request: dict[str, Any] = {
            "model": self._model,
            "max_tokens": max_tokens,
            "messages": built_messages,
        }
        if sys_blocks:
            request["system"] = sys_blocks
        output_config = self._reasoning_output_config(kwargs)
        if output_config is not None:
            request["output_config"] = output_config

        resp = await self._client.messages.create(**request)
        usage = _extract_usage(resp.usage, resp.model or self._model)
        cost = _compute_cost(usage, self._cost_fn)
        if cost is not None:
            usage["cost_usd"] = cost
        self._record_usage(usage, source=source)
        self.last_usage = usage

        text = _collect_text(resp.content)
        return {"text": text, "usage": usage}

    # ── Streaming ──────────────────────────────────────────────────────────────

    async def stream_complete(
        self,
        system: str | None,
        messages: list[dict],
        *,
        source: str | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[str, None]:
        json_mode = kwargs.get("response_format", {}).get("type") == "json_object"
        sys_blocks = _system_blocks(system, prompt_caching=self._prompt_caching)
        built_messages = _build_messages(messages, prompt_caching=self._prompt_caching)
        if json_mode:
            built_messages = _append_json_reminder(built_messages)

        request: dict[str, Any] = {
            "model": self._model,
            "max_tokens": self._max_tokens,
            "messages": built_messages,
        }
        if sys_blocks:
            request["system"] = sys_blocks
        output_config = self._reasoning_output_config(kwargs)
        if output_config is not None:
            request["output_config"] = output_config

        async with self._client.messages.stream(**request) as stream:
            yielded = False
            async for text in stream.text_stream:
                yielded = True
                yield text

            final = await stream.get_final_message()
            # Bedrock (AnthropicBedrock client) sometimes delivers the full
            # response as a single content_block_start rather than incremental
            # text_delta events, so text_stream yields nothing. Recover the
            # text from the final message so callers never see an empty stream.
            if not yielded:
                text = _collect_text(final.content)
                if text:
                    yield text

            usage = _extract_usage(final.usage, final.model or self._model)
            cost = _compute_cost(usage, self._cost_fn)
            if cost is not None:
                usage["cost_usd"] = cost
            self._record_usage(usage, source=source)
            self.last_usage = usage

    def _reasoning_output_config(self, kwargs: dict[str, Any]) -> dict[str, Any] | None:
        existing = kwargs.get("output_config")
        output_config = dict(existing) if isinstance(existing, dict) else {}
        effort = (
            validate_reasoning_effort(
                kwargs["reasoning_effort"],
                provider="anthropic",
                allowed=ANTHROPIC_REASONING_EFFORTS,
            )
            if "reasoning_effort" in kwargs
            else self._reasoning_effort
        )
        if effort is not None:
            output_config["effort"] = effort
        return output_config or None

    # ── Internals ─────────────────────────────────────────────────────────────

    def _record_usage(self, usage: dict, *, source: str | None) -> None:
        """Forward usage to the budget guard.

        Token count for budget purposes is the total input that hit the wire
        — non-cached + cache-creation + cache-read — so token caps reflect
        real wall-clock consumption regardless of cache hit rate. Cost
        (which respects cache pricing via ``cost_fn``) is reported when
        known.
        """
        guard = self._budget
        if not guard:
            return
        tokens_in = (
            int(usage.get("tokens_in") or 0)
            + int(usage.get("cache_read_tokens") or 0)
            + int(usage.get("cache_creation_tokens") or 0)
        )
        tokens_out = int(usage.get("tokens_out") or 0)
        if (tokens_in or tokens_out) and hasattr(guard, "add_tokens"):
            guard.add_tokens(tokens_in, tokens_out, source=source)
        cost = usage.get("cost_usd")
        if cost and cost > 0:
            guard.add_cost(cost, source=source)


# ── Module-level helpers ──────────────────────────────────────────────────────


def _system_blocks(system: str | None, *, prompt_caching: bool) -> list[dict[str, Any]]:
    """Return the system param as a content-block list (or empty list for no system)."""
    if not system:
        return []
    block: dict[str, Any] = {"type": "text", "text": system}
    if prompt_caching:
        block["cache_control"] = {"type": "ephemeral"}
    return [block]


def _build_messages(messages: list[dict], *, prompt_caching: bool) -> list[dict[str, Any]]:
    """Convert harness message dicts to Anthropic message format.

    System-role messages are silently dropped (callers should pass them via
    the `system` parameter). The last user message gets `cache_control` when
    prompt_caching is enabled.
    """
    built: list[dict[str, Any]] = []
    for msg in messages:
        role = msg.get("role", "user")
        if role == "system":
            continue  # consumed by caller as the system param
        if role not in {"user", "assistant"}:
            role = "user"
        content = msg.get("content", "")
        built.append(
            {
                "role": role,
                "content": [{"type": "text", "text": str(content)}],
            }
        )

    if prompt_caching:
        _apply_last_user_cache_control(built)

    return built


def _apply_last_user_cache_control(messages: list[dict]) -> None:
    """Add cache_control to the last user message's single text block."""
    for message in reversed(messages):
        if message.get("role") != "user":
            continue
        content = message.get("content")
        if isinstance(content, list) and len(content) == 1 and content[0].get("type") == "text":
            content[0]["cache_control"] = {"type": "ephemeral"}
        break


def _extract_usage(usage: Any, model: str) -> dict:
    """Build the standard harness usage dict from an Anthropic usage object."""
    return {
        "tokens_in": getattr(usage, "input_tokens", 0),
        "tokens_out": getattr(usage, "output_tokens", 0),
        "cache_read_tokens": getattr(usage, "cache_read_input_tokens", 0) or 0,
        "cache_creation_tokens": getattr(usage, "cache_creation_input_tokens", 0) or 0,
        "model": model,
    }


def _collect_text(content: Any) -> str:
    """Extract plain text from an Anthropic response content list."""
    if not content:
        return ""
    parts: list[str] = []
    for block in content:
        if hasattr(block, "text"):
            parts.append(block.text)
        elif isinstance(block, dict) and block.get("type") == "text":
            parts.append(block.get("text", ""))
    return "".join(parts)


def _compute_cost(usage: dict, cost_fn: Callable[[dict], float] | None) -> float | None:
    if cost_fn is None:
        return None
    try:
        return float(cost_fn(usage))
    except Exception as e:
        logger.warning("cost_fn raised: %s — skipping cost for this call", e)
        return None
